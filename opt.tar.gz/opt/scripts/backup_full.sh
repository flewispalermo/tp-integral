#!/bin/bash

set -e

ayuda () {
 echo ""
 echo "Para ejecutar este comando debe ingresar ./backup.sh ORIGEN DESTINO"
 echo ""
 echo "Por ejemplo: ./backup.sh /var/log /logs"
 echo ""
}

error(){
 echo "$1" >&2
 exit 1
}

validar_origen(){
 ORIGEN=$1

 if [[ $ORIGEN == "/" ]]; then
   error "No se puede hacer backup del directorio /"
 fi

 if [[ ! -d $ORIGEN ]]; then
   error "No se encontro el directorio de origen: $ORIGEN" 
 fi


 if [[ ! -r $ORIGEN ]]; then
   error "El directorio de origen: $ORIGEN no tiene permisos de lectura"
 fi
}

validar_destino() {
 DESTINO=$1
 ARCHIVO=$2

 RUTA_ARCHIVO=$DESTINO"/"$ARCHIVO
 
 if [[ ! -d $DESTINO ]]; then
  error "No se encontro el directorio de destino: $DESTINO"
 fi
 
 if [[ ! -w $DESTINO ]]; then
  error "No se tiene permisos para crear el archivo en $DESTINO"
 fi 

 if [[ -e $RUTA_ARCHIVO ]]; then
  error "El archivo de backup a generarse ya existe"
 fi
}

generar_archivo() {
 CARPETA=$1
 ARCHIVO=$2
 ORIGEN=$3


 echo "Generando archivo $ARCHIVO en $CARPETA"
 `tar -czf $CARPETA"/"$ARCHIVO $ORIGEN`
}


backup() {
 ORIGEN=$1
 DESTINO=$2

 CARPETA_BACKUP="/backup_dir/${DESTINO#/}"

 validar_origen $ORIGEN
 
 CARPETA_ORIGEN=`basename "$ORIGEN"`
 HOY=`date +"%Y%m%d"`
 ARCHIVO=$CARPETA_ORIGEN"_log_"$HOY".tar.gz"

 validar_destino $CARPETA_BACKUP $ARCHIVO

 generar_archivo $CARPETA_BACKUP $ARCHIVO $ORIGEN

 echo "Se ha generado el archivo de backup $CARPETA_BACKUP/$ARCHIVO"
}

if [[ $# == 2 ]]; then
  backup $1 $2
elif [[ $1 == "-help" ]]; then 
 ayuda
else
 echo "Debe ingresar un origen y un destino. Para más información utilice la oion -help"
fi

BACKUP="/backup_dir"

